minute = 60.
hour   = 60.*minute
day    = 24.*hour
week   = 7.*day
year   = 365.*day
