def flat(sim):
    pass
