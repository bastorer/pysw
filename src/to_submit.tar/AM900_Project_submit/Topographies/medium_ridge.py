import numpy as np

def medium_ridge(sim):
    W = 20.e3
    if sim.Nx > 1 and sim.Ny > 1:
        X,Y = np.meshgrid(sim.x,sim.y,indexing='ij')
        r0 = np.sqrt( (1.*sim.Lx/4)**2 + (1./sim.Ly/4)**2)
        r = np.sqrt((X-sim.Lx/2.)**2 + (Y-sim.Ly/2.)**2)
        tmp = np.exp(-(r-r0)**2/(W**2))
    elif sim.Nx > 1:
        r0 = 1.*sim.Lx/4
        r = np.sqrt((x-sim.Lx/2.)**2)
        tmp = np.exp(-(r-r0)**2/(W**2))
        tmp = tmp.reshape((sim.Nx,1))
    elif sim.Ny > 1:
        r0 = 1.*sim.Ly/4
        r = np.sqrt((y-sim.Ly/2.)**2)
        tmp = np.exp(-(r-r0)**2/(W**2))
        tmp = tmp.reshape((sim.Ny,1))

    sim.sol[sim.Ih,:,:,-1] = 0.99*np.sum(sim.Hs)*tmp

