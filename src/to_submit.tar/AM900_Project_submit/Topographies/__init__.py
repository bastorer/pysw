# Steppers
#    This module provides the time-stepping
#    functions used for the simulator class.

__author__ = "Ben Storer <bastorer@uwaterloo.ca>"
__date__   = "16th of March, 2015"

# Import the functions
from big_wedge import big_wedge
from big_ridge import big_ridge
from medium_ridge import medium_ridge
from small_ridge import small_ridge
from big_sine import big_sine
from medium_sine import medium_sine
from small_sine import small_sine
from flat import flat
