import numpy as np

def big_wedge(sim):
    if sim.Nx > 1 and sim.Ny > 1:
        X,Y = np.meshgrid(sim.x,sim.y,indexing='ij')
        tmpx = 2*abs(sim.X/sim.Lx - 0.5)
        tmpy = 2*abs(sim.Y/sim.Ly - 0.5)
        tmp  = tmpx*tmpy
    elif sim.Nx > 1:
        tmp = -4*(sim.x/sim.Lx - 0.25)*(sim.x/sim.Lx < 0.25) +\
               4*(sim.x/sim.Lx - 0.75)*(sim.x/sim.Lx > 0.75)
        tmp = tmp.reshape((sim.Nx,1))
    elif sim.Ny > 1:
        tmp = 2*abs(sim.y/sim.Ly - 0.5)
        tmp = tmp.reshape((sim.Ny,1))
    sim.sol[sim.Ih,:,:,-1] = 1.1*np.sum(sim.Hs)*tmp

