import numpy as np

def medium_sine(sim):
    if sim.Nx > 1 and sim.Ny > 1:
        X,Y = np.meshgrid(sim.x,sim.y,indexing='ij')
        tmpx = (1+np.cos(2*np.pi*X/sim.Lx))/2.
        tmpy = (1+np.cos(2*np.pi*Y/sim.Ly))/2.
        tmp  = tmpx*tmpy
    elif sim.Nx > 1:
        tmp = (1+np.cos(2*np.pi*sim.x/sim.Lx))/2.
        tmp = tmp.reshape((sim.Nx,1))
    elif sim.Ny > 1:
        tmp = (1+np.cos(2*np.pi*sim.y/sim.Ly))/2.
        tmp = tmp.reshape((sim.Ny,1))

    sim.sol[sim.Ih,:,:,-1] = np.sum(sim.Hs)*tmp

