import numpy as np
import sys

def FV_advection(sim):

    #Initialize etas
    for ii in range(sim.Nz-1,-1,-1):
        sim.sol[sim.Ih,:,:,ii] = sim.sol[sim.Ih,:,:,ii+1] + sim.Hs[ii]

    if sim.Nx > 1 and sim.Ny > 1:
        x0 = sim.Lx/2.
        y0 = sim.Ly/4.
        X,Y = np.meshgrid(sim.x,sim.y,indexing='ij')

        sim.sol[sim.Iu,:,:,0] = 2.+0.*X #-np.pi*0.5*(Y-sim.Ly/2)/sim.Ly

        sim.sol[sim.Iv,:,:,0] = 3.+0.*Y # np.pi*0.5*(X-sim.Lx/2)/sim.Lx

        sim.sol[sim.Ih,:,:,0] += np.exp(-((X-x0)**2 + (Y-y0)**2)/(10e3)**2)

    elif sim.Nx > 1:

        x  = sim.x
        x0 = sim.Lx/2

        #sim.sol[sim.Iu,:,:,0] = (2+0.*x).reshape((sim.Nx,1))
        sim.sol[sim.Iu,:,:,0] = (1.+np.sin(2*np.pi*x/sim.Lx)).reshape((sim.Nx,1))

        gau = 20*(np.exp(-(x-x0)**2/(10e3)**2))

        sim.sol[sim.Ih,:,:,0] += (gau).reshape((sim.Nx,sim.Ny))
    elif sim.Ny > 1:

        y  = sim.y
        y0 = sim.Ly/2

        sim.sol[sim.Iv,:,:,0] = (2+0.*y).reshape((sim.Nx,sim.Ny))

        gau = 20*(np.exp(-(y-y0)**2/(10e3)**2))

        sim.sol[sim.Ih,:,:,0] += (gau).reshape((sim.Nx,sim.Ny))

