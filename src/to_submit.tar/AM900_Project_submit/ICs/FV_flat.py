import numpy as np
import sys

def FV_flat(sim):

    #Initialize etas
    for ii in range(sim.Nz-1,-1,-1):
        # Initialize to be flat
        sim.sol[sim.Ih,:,:,ii] = sim.Hs[ii]

    # Need to make sure we're above the topography by at least min_depth
    for ii in range(sim.Nz-1,-1,-1):
        # Difference in depth
        tmp =  sim.sol[sim.Ih,:,:,ii] - sim.sol[sim.Ih,:,:,ii+1] - sim.min_depth
        tmp = -np.minimum(tmp,np.zeros(tmp.shape)) # Amount to add to fix
        sim.sol[sim.Ih,:,:,ii] += tmp
