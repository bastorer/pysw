# ICs
#    This module provides the initial condition
#    functions used for the simulator class.

__author__ = "Ben Storer <bastorer@uwaterloo.ca>"
__date__   = "16th of March, 2015"

# Import the functions
from FV_gauss import FV_gauss
from FV_flat import FV_flat
from FV_burger import FV_burger
from FV_advection import FV_advection
