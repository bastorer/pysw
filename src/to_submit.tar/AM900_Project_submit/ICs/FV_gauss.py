import numpy as np
import sys

def FV_gauss(sim):

    #Initialize etas
    for ii in range(sim.Nz):
        # Initialize to be flat
        sim.sol[sim.Ih,:,:,ii] = np.sum(sim.Hs[ii:])

    if sim.Nx > 1 and sim.Ny > 1:
        x0 = sim.Lx/2
        y0 = sim.Ly/2
        W  = 30.e3 
        amp = 5.
        X,Y = np.meshgrid(sim.x,sim.y,indexing='ij')
        tmp = np.exp(-((X-x0)**2 + (Y-y0)**2)/(W**2))
        sim.sol[sim.Ih,:,:,0] += amp*tmp

    elif sim.Nx > 1:
        x0 = 1.*sim.Lx/2.
        W  = 30.e3 
        amp = 10. 
        tmp = np.exp(-(sim.x-x0)**2/(W**2)).reshape((sim.Nx,1))
        sim.sol[sim.Ih,:,:,0] += amp*tmp

    elif  sim.Ny > 1:
        y0 = sim.Ly/2
        tmp = np.exp(-(sim.y-y0)**2/(10e3)**2).reshape((1,sim.Ny))
        sim.sol[sim.Ih,:,:,0] += 10.*tmp

    # Need to make sure we're above the topography by at least min_depth
    for ii in range(sim.Nz-1,-1,-1):
        # Difference in depth
        tmp =  sim.sol[sim.Ih,:,:,ii] - sim.sol[sim.Ih,:,:,ii+1] - 2*sim.min_depth
        tmp = -np.minimum(tmp,np.zeros(tmp.shape)) # Amount to add to fix
        sim.sol[sim.Ih,:,:,ii] += tmp
