import numpy as np
import sys

def FV_burger(sim):

    sim.sol[sim.Ih,:,:,0] = 1.

    if sim.Nx > 1 and sim.Ny > 1:
        x0 = sim.Lx/2;
        y0 = sim.Ly/2;
        X,Y = np.meshgrid(sim.x,sim.y,indexing='ij')

        tmp = np.exp(-((X-x0)**2 + (Y-y0)**2)/(1)**2)
        sim.sol[sim.Iu,:,:,0] = tmp

    elif sim.Nx > 1:

        x0 = 3.*sim.Lx/4.
        tmp1 =  np.exp(-(sim.x-x0)**2/(1.)**2).reshape((sim.Nx,1))

        x0 = 1.*sim.Lx/4.
        tmp2 = -np.exp(-(sim.x-x0)**2/(1.)**2).reshape((sim.Nx,1))

        sim.sol[sim.Iu,:,:,0] = tmp1 + tmp2

    elif  sim.Ny > 1:
        y0 = sim.Ly/2;
        tmp = np.exp(-(sim.y-y0)**2/(1)**2).reshape((1,sim.Ny))
        sim.sol[sim.Iu,:,:,0] = tmp

