import numpy as np
from Simulators import Sadourny
import Steppers as ts
import Fluxes as fx
import ICs as ICs
import Topographies as Tops
import Differentiation as Diff
import matplotlib.pyplot as plt
import sys
import matpy as mp
from constants import minute, hour, day

# Initialize simulation
sim = Sadourny()
sim.run_name = 'zhang_msine_f'

# Specify geometry conditions (creates differentiation procedures)
sim.x_derivs = Diff.FV_x_WENO
sim.y_derivs = Diff.FV_y_WENO

# Specify initial conditions
sim.IC_func = ICs.FV_gauss

# Specify topography
sim.topo_func = Tops.medium_sine

# Specify time-stepping algorithm
sim.time_stepper  = ts.TVD_RK3

# Specify flux function
sim.flux_function = fx.fv_sw_flux_zhang

# Specify source function
sim.source_function = fx.fv_sw_source_zhang

# Specify plotting options
sim.animate = 'Save'   # 'None', 'Anim', or 'Save'
sim.ptime   = 5.*minute    # Number of seconds between steps

sim.diagnose = True  # True or False
sim.dtime    = 5.*minute   # Number of seconds between diagnostic times.

sim.output  = False
sim.otime   = 6*minute

# Specify parameters
sim.Lx   = 400.e3
sim.Ly   = 400.e3
sim.Nx   = 128*8
sim.Ny   = 1
sim.Nz   = 1
sim.f0   = 1.e-4
sim.cfl  = 0.002
sim.g    = 9.81
sim.min_depth = 1.e-3
sim.min_dt = 1e-10
sim.vanishing = False # True if using Salmon
sim.limiter = 'Zhang'

# Specify layer parameters
H = 50.#1.e2
sim.rho = np.linspace(1020.,1030.,sim.Nz)
sim.Hs  = [1./sim.Nz*H]*sim.Nz # Equal depth

# Initialize the simulation
sim.initialize()
sim.end_time =  12.*hour
sim.run()
